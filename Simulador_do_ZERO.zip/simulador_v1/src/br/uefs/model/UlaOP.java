package br.uefs.model;

public class UlaOP {
	
	public UlaOP()
	{
		super();
	}
	
	public int operation_R(int opcode, int func,  int operandoRA, int operandoRB) 
	{
		if(opcode == 0b000000 && (func == 0b100000 || func == 0b100001)) { 
			return ULA.ADD(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && (func == 0b100010|| func == 0b100011)) {
			return ULA.ADD(operandoRA, (operandoRB*-1) );
		}
		else if(opcode == 0b000000 && func == 0b100100) {
			return ULA.AND(operandoRA, operandoRB);		
		}
		else if(opcode == 0b000000 && func == 0b100101) {
			return ULA.OR(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && func == 0b100110) { 
			return ULA.XOR(operandoRA, operandoRB);
		}
		else if(opcode == 0b011100 && func == 0b000010) { 
			return ULA.MUL(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && func == 0b100111) {
			return ULA.NOR(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && (func == 0b000000 || func == 0b000100)) {
			return ULA.SLL(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && (func == 0b000010 || func == 0b000110)) {
			return ULA.SRL(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && (func == 0b000011 || func == 0b000111)) {
			return ULA.SRA(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && func == 0b001011) {
			return ULA.MOVN(operandoRA);
		}
		else if(opcode == 0b000000 && func == 0b001010) {
			return ULA.MOVZ(operandoRA, operandoRB);
		}
		else if(opcode == 0b000000 && (func == 0b101010 || func == 0b101011)) {
			return ULA.SLT(operandoRA, operandoRB);
		}
		else {
			return 0;
		}
	}
	public int operation_I(int opcode,  int operandoRA, int operando_const) 
	{
		
		if(opcode == 0b001000 || opcode == 0b001001) {
			return ULA.ADD(operandoRA, operando_const);
		}
		else if(opcode == 0b000100) {
			return ULA.BEQ(operandoRA, operando_const);
		}
		else if(opcode == 0b000101) {
			return ULA.BNE(operandoRA, operando_const);
		}
		else if(opcode == 0b001010 || opcode == 0b001011) {
			return ULA.SLT(operandoRA, operando_const);
		}
		else if(opcode == 0b001100) {
			return ULA.AND(operandoRA, operando_const);
		}
		else if(opcode == 0b001101) {
			return ULA.OR(operandoRA, operando_const);
		}
		else if(opcode == 0b001110) {
			return ULA.XOR(operandoRA, operando_const);
		}
		else 
			return 0;
	}

	public int[] operacao_accumulador(int int_token_0_5, int funcao, int valor, int valor2) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
	

}
