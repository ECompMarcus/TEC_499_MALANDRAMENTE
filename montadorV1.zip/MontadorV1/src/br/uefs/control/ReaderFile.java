package br.uefs.control;

import java.awt.Label;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

import br.uefs.debuger.Debuger;
import br.uefs.lib.Instructions;
import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;


public class ReaderFile {

	public static LinkedList<RefInstruc> instrucoes_lidas = new LinkedList<RefInstruc>();
	public static LinkedList<String> dados_lidos = new LinkedList<String>();
	
	static int numberLine = 0;
	static boolean statusERROR = false;
	static int erros = 0;

	
	public static  void readerFile(String name) throws IOException
	{
		FileInputStream stream = new FileInputStream(name);
		InputStreamReader reader = new InputStreamReader(stream);
		BufferedReader br = new BufferedReader(reader);
		stream = new FileInputStream(name);
	
		String line = br.readLine();
		String[] mtokens;
		RefInstruc x = null;
		//System.err.println(line);
		boolean data = false;
		while (line != null) {
			
		
			
			mtokens = tokenizeR(line);
			if(identify(mtokens[0]))
			{
				if(Library.diretivas[0].equals(mtokens[0]))
					data=true;
				
				if(!data)
				{
					mtokens[0] = mtokens[0].toUpperCase();
					Debuger.sysPrinfT(mtokens[0]);
					x = new RefInstruc(mtokens, numberLine);
					instrucoes_lidas.add(x);
					numberLine++;
				}
				else{
					
					if(mtokens[0].matches("\\w+\\d*?\\:$"))
					{
						Library.labellist.add(mtokens[0]);
						
						x = new RefInstruc(mtokens, numberLine);
						ReaderFile.instrucoes_lidas.add(x);
						
						if(!(mtokens.length == 1))
						{
							if( Library.diretivas[4].equals(mtokens[1]) )
							{
								dados_lidos.add(""+mtokens[2]);
								numberLine++;
							}
							
						}
					}
					if(Library.diretivas[4].equals(mtokens[0]))
					{
						dados_lidos.add(""+mtokens[1]);			
						numberLine++;
					}
				}
			}
			
			line = br.readLine();
		}
	}
	private static String[] tokenizeR(String linha)
	{
		linha = linha.trim();
		String [] tokens;
		String [] tokensF;
		//System.err.println(linha);
		
		tokens = linha.split("[\\t - \\s - \\,]");
		//tokensF = new String[tokens.length];
		String subLinha="";
		int j = 0;
		for(int i = 0 ; i <tokens.length; i ++)
		if(!tokens[i].equals(""))
		{
			subLinha += tokens[i]+"\t";
			
		}
		tokensF = subLinha.split("\t");
		/*
		for(int i=0; i <tokensF.length; i++)
			System.err.print(tokensF[i]+"\t");
		System.err.println("");
		*/
		return tokensF;
	}
	
	private static boolean identify(String linha)
	{
		
		for (int i = 0; i < Library.diretivas.length; i++) {
			if (Library.diretivas[i].equals(linha)) {
				return true;
			}
		}
		
		if(linha.matches("^;.*"))
			return false;
		else if (linha.matches("\\w+\\d*?\\:$")) {
			//System.out.println(linha);
			Library.labellist.add(linha);
			//x = new RefInstruc(aux.split("[\\t - \\s]"), numberLine);
			//instrucoes_lidas.add(x);
			return true;
		} else if(Library.list_instructions.contains(new Instructions(linha.toUpperCase(),"1"))){
			//System.out.println(linha.toUpperCase());
			//linha = linha.toUpperCase();
		//	x = new RefInstruc(aux.split("[\\t - \\s - \\,]"), numberLine);
		//	instrucoes_lidas.add(x);
			
			return true;
		}
		return false;
	}

}
