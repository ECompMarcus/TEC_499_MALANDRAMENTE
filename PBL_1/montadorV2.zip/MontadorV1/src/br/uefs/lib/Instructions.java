package br.uefs.lib;

public class Instructions {

	private String name;
	private String function;
	private String opcode;
	private String shitfAmount;
	private int type;
	private int operandos;

	public Instructions(String string, String string3) {
		super();
		setName(string);
		setType(Integer.parseInt(string3));
	}

	public Instructions(String opcode,String name, Integer type,String function, String operandos,String shiftAmount)
	{
		super();
		setName(name);
		setOperandos(Integer.parseInt(operandos));
		setFunction(function);
		setOpcode(opcode);
		setType(type);
		setShitfAmount(shiftAmount);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public void setType(int value) {
		this.type = value;
	}

	public int getOperandos() {
		return operandos;
	}

	public void setOperandos(int operandos) {
		this.operandos = operandos;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getOpcode() {
		return opcode;
	}

	public void setOpcode(String opcode) {
		this.opcode = opcode;
	}

	public boolean equals(Object o) {
		if (o instanceof Instructions) {
			Instructions x = (Instructions) o;
			if (this.name.equals((x).getName()))
				return true;
		}
		return false;
	}

	public String getShitfAmount() {
		return shitfAmount;
	}

	public void setShitfAmount(String shitfAmount) {
		this.shitfAmount = shitfAmount;
	}

}
