package br.uefs.control;

import br.uefs.debuger.Debuger;
import br.uefs.lib.*;

public class GeneralAnalisy {

	public static int handlerTypeInstructions(String inst) {
		// System.out.println(inst);
		Instructions aux = new Instructions(inst, "1");
		for (int i = 0; i < Library.diretivas.length; i++)
			if (Library.diretivas[i].equals(inst))
				return 99;

		if (inst.matches("\\w+\\d*\\:$")) {
			return 99;
		} else if (Library.list_instructions.contains(aux)) {

			int index = Library.list_instructions.indexOf(aux);
			Instructions a = Library.list_instructions.get(index);

			if (a.getName().equals("LW") || a.getName().equals("LB") || a.getName().equals("LH")
					|| a.getName().equals("SW") || a.getName().equals("SB") || a.getName().equals("SH")) {
				return 5;
			} else if (inst.matches(".*IU")) {
				return 4;
			} else if (a.getName().equals("SRL")||a.getName().equals("SLL") || a.getName().equals("SRA")) {
				return 6;
			} else if (a.getName().equals("BEQ") || a.getName().equals("BNE") || a.getName().equals("BGTZ")
					|| a.getName().equals("BLTZ")) {
				return 7;
			} else if ( a.getName().equals("SEB") 	|| 
						a.getName().equals("SEH") 	|| 
						a.getName().equals("WSBH")	||  
						a.getName().equals("EXT") 	||
						a.getName().equals("INS") 	||
						a.getName().equals("ROTR")	||
						a.getName().equals("ROTRV")	||
						a.getName().equals("SRLV")	||
						a.getName().equals("SRAV")	||
						a.getName().equals("SLLV")	||
						a.getName().equals("MULTU")	||
						a.getName().equals("CLZ")	||
						a.getName().equals("CLO") 	||
						a.getName().equals("JALR")
						){
				
				return 8;
			}
			
			

			return a.getType();
		}
		return 100;
	}

	public boolean instructionsFormatExists(String linha) {

		String[] tokens = linha.trim().split("\t");
		Library.list_instructions.contains(tokens[0]);
		return false;
	}

	public static void writerLogError(String linha) {
		ReaderFile.list_error.add(linha);
		Debuger.sysPrinfT(linha);
		ReaderFile.statusERROR = true;
		ReaderFile.erros++;
	}

	public static Instructions getInstruction(String inst) {
		Instructions aux = new Instructions(inst, "1");
		int index = Library.list_instructions.indexOf(aux);
		return Library.list_instructions.get(index);
	}

}
