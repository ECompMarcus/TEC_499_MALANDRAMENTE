package br.uefs.control;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import br.uefs.debuger.Debuger;
import br.uefs.model.Memoria;
import br.uefs.model.UlaOP;
import br.uefs.model.UnidadeControle;
import br.uefs.model.Registradores;

public class Processador {
	
	
	  public static void main(String[] args) {

		UnidadeControle unidade_de_controle = new UnidadeControle();
		
		
		try {
			loader("test.txt",unidade_de_controle.memoria,unidade_de_controle.banco_registradores);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		unidade_de_controle.banco_registradores.setPc((unidade_de_controle.banco_registradores.getPc() -1) );
		while( unidade_de_controle.banco_registradores.getPc() < (unidade_de_controle.banco_registradores.getValor(28)-2) )
		{
			
			 unidade_de_controle.banco_registradores.setPc((unidade_de_controle.banco_registradores.getPc() +1) );
			 Debuger.sysPrinfT(unidade_de_controle.banco_registradores.getPc()+"");
				
			 unidade_de_controle.decoder(unidade_de_controle.memoria.ler_memoria_32B(unidade_de_controle.banco_registradores.getPc()));
		
		
		}
		for(int i = 0 ; i<32; i++)
		{
			Debuger.sysPrinfT(i+"- "+unidade_de_controle.banco_registradores.getValor(i));
		}
	}
	
	public static void loader(String nome_arquivo, Memoria memoria,Registradores banco_registradores ) throws IOException
	{
		
		 	FileInputStream stream = new FileInputStream(nome_arquivo);
	        InputStreamReader reader = new InputStreamReader(stream);
	        BufferedReader br = new BufferedReader(reader);
	        
	        String linha = br.readLine();
	     
	        boolean number = true;
			int instruNumber = 0 , internalMemorySize = 0 ;
			while (linha != null) {

	            if (number) {
	                instruNumber = Integer.parseInt(linha, 2);
	                Debuger.sysPrinfT(instruNumber+"");
	                number = false;
	            } else {
	            	memoria.escrever_memoria_32B(internalMemorySize++, linha);
	            	  Debuger.sysPrinfT(linha);
	            }
	         
	            linha = br.readLine();
	        }
			banco_registradores.setValor(28, instruNumber+1);
			banco_registradores.setValor(29, internalMemorySize+1);
			banco_registradores.setValor(30, internalMemorySize+1);
			banco_registradores.setPc(0);
	}
}
