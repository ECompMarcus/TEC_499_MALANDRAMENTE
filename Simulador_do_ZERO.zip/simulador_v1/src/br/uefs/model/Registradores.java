package br.uefs.model;

public class Registradores {
	
	int size = 32;
	int []GPR = new int[size];
	private int Hi, Lo; 
	private int pc;
	
	public Registradores()
	{
		limpar();
	}
	public void limpar()
	{
		for(int i = 0 ; i < size; i ++ )
		{
			GPR[i] = 0;
		}
		Hi = 0;
		Lo = 0;
	}
	
	public int getValor(int i )
	{
		return GPR[i];
	}
	public void setValor(int gpr, int valor )
	{
		GPR[gpr] = valor;
	}

	public int getHi() {
		return Hi;
	}

	public void setHi(int hi) {
		Hi = hi;
	}

	public int getLo() {
		return Lo;
	}

	public void setLo(int lo) {
		Lo = lo;
	}
	public int getPc() {
		return pc;
	}
	public void setPc(int pc) {
		this.pc = pc;
	}
}
