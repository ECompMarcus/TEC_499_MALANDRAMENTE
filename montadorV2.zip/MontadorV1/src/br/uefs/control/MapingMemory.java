package br.uefs.control;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import br.uefs.debuger.Debuger;
import br.uefs.lib.Instructions;
import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;

public class MapingMemory {

	static int sizeMemory = 1000;
	static String[] Memoria = new String[sizeMemory];
	static LinkedList<String> memoria_flash = new LinkedList<String>();
	static int currentLine = 0;
	public static void map() 
	{
		String word_32bits = "";
		for (RefInstruc aux : ReaderFile.instrucoes_lidas) 
		{	word_32bits = "";
			ReaderFile.statusERROR = false;
			
			int index = GeneralAnalisy.handlerTypeInstructions(aux.LinhaIntr[0]);
			Instructions Inst_Aux = null;
			// System.err.println(index);
			if (index < 99)
			{
				Inst_Aux = GeneralAnalisy.getInstruction(aux.LinhaIntr[0]);
			}
			else if (index == 100)
			{
				GeneralAnalisy.writerLogError(
						"Verifique se est� correto:  " + aux.LinhaIntr[0]);
			}
			
			
			if (!ReaderFile.statusERROR) 
			{
				//INICIO INSTRU��ES  R
				if (index == 0) 
				{ 
					word_32bits = mapInst_R(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				}	
				//FIM INSTRU��ES  R 
				// INICIO INSTRU��ES I
				else if (index == 1) 
				{ 
					word_32bits = mapInst_I(Inst_Aux, aux);
					memoria_flash.add(word_32bits);
				}
				// FIM INSTRU��ES I
				// INICIO INSTRU��ES  J
				else if (index == 2)
				{ 
					word_32bits = mapInst_J(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				}
				// FIM INSTRU��ES  J
				// INICIO INSTRU��ES COM IU
				else if (index == 4)
				{ 
					word_32bits = mapInst_IU_UI(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				} 
				// FIM INTRU��O COM UNSINGED
				// INICIO INSTRU��O LOAD E STORE
				else if (index == 5)
				{ 
					word_32bits = mapInst_L_S(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				}
				// FIM INSTRU��O LOAD E STORE
				// INICIO INSTRU��ES T - R SHIFT
				else if (index == 6)
				{
					word_32bits = mapInst_SHIFT(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				} 
				// FIM INSTRU��o T - R SHIFT
				// INICIO INSTRU��ES BRANCH
				else if (index == 7)
				{ 
					word_32bits = mapInst_BRANCH(Inst_Aux,aux);
					memoria_flash.add(word_32bits);
				}
				else if(index == 8)
				{ 	// caso especial SEB
					word_32bits = mapInst_ESPECIAL(Inst_Aux,aux);
					
					
					memoria_flash.add(word_32bits+""); // AQUI JA TA NULL
				}
				// FIM INSTRU��ES BRANCH
				currentLine++;
			}
			//System.err.println(ReaderFile.dados_lidos.size());
			
		
		}
	
		for(String x: ReaderFile.dados_lidos)
		{
			Debuger.sysPrinfT(Library.getBin32(x));
			memoria_flash.add(Library.getBin32(x));
			
		}
	
	}
	
	
	private static String mapInst_ESPECIAL(Instructions Inst_Aux, RefInstruc aux)
	{
		String word_32bits = "";
		
		if(Inst_Aux.getName().equals("SEB"))
		{
			//SEB rd, rt
			word_32bits = Inst_Aux.getOpcode()
					+""+Library.ZERO
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+"10000"+
					Inst_Aux.getFunction();
		}
		else if(Inst_Aux.getName().equals("SEH"))
		{
			word_32bits = Inst_Aux.getOpcode()
					+""+Library.ZERO
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+"11000"+
					Inst_Aux.getFunction();
			
		}else if(Inst_Aux.getName().equals("WSBH"))
		{
			//WSBH rd, rt
			word_32bits = Inst_Aux.getOpcode()
					+""+Library.ZERO
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+"00010"+
					Inst_Aux.getFunction();
		}else if(Inst_Aux.getName().equals("EXT"))
		{
//			ext $s0, $s1, 5, 10
//			ins $s0, $s1, 5, 10
			Integer f = (Integer.parseInt(aux.LinhaIntr[4])-1 );
			word_32bits = Inst_Aux.getOpcode()
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+""+Library.signalExt(f+"", 5)
					+""+Library.signalExt(Integer.parseInt(aux.LinhaIntr[3])+"", 5)
					+""+Inst_Aux.getFunction();
		}else if(Inst_Aux.getName().equals("INS"))
		{
//			INS rt, rs, pos, size
			Integer f = (Integer.parseInt(aux.LinhaIntr[3]) + Integer.parseInt(aux.LinhaIntr[4]) -1 );
			
			word_32bits = Inst_Aux.getOpcode()										// OP
					+""+Library.getCodeReg(aux.LinhaIntr[2])						// RS
					+""+Library.getCodeReg(aux.LinhaIntr[1])						// RT
					+""+Library.signalExt(f+"", 5)									// POS+SIZE-1
					+""+Library.signalExt(Integer.parseInt(aux.LinhaIntr[3])+"", 5) // POS
					+""+Inst_Aux.getFunction();										// FUN
		}
		else if(Inst_Aux.getName().equals("ROTR"))
		{
			
			word_32bits = Inst_Aux.getOpcode()
					+"00001"+
					Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+""+Library.signalExt(aux.LinhaIntr[3], 5)
					+""+Inst_Aux.getFunction();
		}
		else if(Inst_Aux.getName().equals("ROTRV"))
		{
			
			word_32bits = Inst_Aux.getOpcode()+""+
					Library.getCodeReg(aux.LinhaIntr[3])
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+"00001"
					+""+Inst_Aux.getFunction();
		}
		else if(Inst_Aux.getName().equals("SLLV")||Inst_Aux.getName().equals("SRLV") || Inst_Aux.getName().equals("SRAV"))
		{
			word_32bits = Inst_Aux.getOpcode()
					+""+Library.getCodeReg(aux.LinhaIntr[3])
					+""+Library.getCodeReg(aux.LinhaIntr[2])
					+""+Library.getCodeReg(aux.LinhaIntr[1])
					+""+Library.ZERO
					+""+Inst_Aux.getFunction();
		}
		else if (Inst_Aux.getName().equals("MULTU"))
		{
			//MULTU rs, rt
			//SPECIAL rs rt 0110
			word_32bits = 
					Inst_Aux.getOpcode()						// OP
					+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RS
					+""+ Library.getCodeReg(aux.LinhaIntr[2])	// RT
					+""+ Library.ZERO 							// 5(0)
					+""+ Inst_Aux.getShitfAmount() 				// SH
					+""+ Inst_Aux.getFunction();				// FUN
			
		}else if(Inst_Aux.getName().equals("CLZ")||Inst_Aux.getName().equals("CLO"))
		{
			word_32bits = 
					Inst_Aux.getOpcode()						// OP
					+""+ Library.getCodeReg(aux.LinhaIntr[2])	// RS
					+""+ Library.ZERO							// 5(0)
					+""+ Library.getCodeReg(aux.LinhaIntr[1]) 	// RD
					+""+ Inst_Aux.getShitfAmount() 				// SH
					+""+ Inst_Aux.getFunction();				// FUN
			
		}else if (Inst_Aux.getName().equals("JALR"))
		{
			word_32bits = 
					Inst_Aux.getOpcode()						// OP
					+""+  Library.getCodeReg(aux.LinhaIntr[2])	// RS
					+""+ Library.ZERO  							// RT
					+""+ Library.getCodeReg(aux.LinhaIntr[1])							// RD
					+""+ Inst_Aux.getShitfAmount() 				// SH
					+""+ Inst_Aux.getFunction();				// FUN
		}
		//Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}


	private static String mapInst_BRANCH(Instructions Inst_Aux, RefInstruc aux)
	{	
		String word_32bits = "";
		int op = Inst_Aux.getOperandos();
		if (op == 3)
		{
			for (int i = 1; i < op-1; i++) 
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError("Verifique os Registrador: " + aux.LinhaIntr[i]);
				}
			}
			aux.LinhaIntr[op] += ":";
			if (!Library.labellist.contains(aux.LinhaIntr[op]))
			{
				GeneralAnalisy.writerLogError("Verificar a Label: " + aux.LinhaIntr[op] );
			}
			if (!ReaderFile.statusERROR)
			{
				RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[3].toUpperCase().split("\t"), 1);
				//System.err.println(aux.LinhaIntr[3]);
				aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));

				word_32bits = 
						Inst_Aux.getOpcode()										// OP
						+""+ Library.getCodeReg(aux.LinhaIntr[1])					// RS
						+"" + Library.getCodeReg(aux.LinhaIntr[2]) 					// RT
						+""+ Library.signalExt((aux1.linha-currentLine+1) + "", 16);//	OFFSET	
			}
		}
		else if(op ==2)
		{
				if (!Library.registradores.containsKey(aux.LinhaIntr[1]))
				{
					GeneralAnalisy.writerLogError("Verifique os Registrador: " + aux.LinhaIntr[1]);
				}
			/*
				aux.LinhaIntr[2] += ":";
				if (!Library.labellist.contains(aux.LinhaIntr[2]))
				{
					GeneralAnalisy.writerLogError("Verificar a Label: " + aux.LinhaIntr[2] );
				}
			*/
			if (!ReaderFile.statusERROR)
			{
				aux.LinhaIntr[2]+=":";
				RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[2].toUpperCase().split("\t"), 1);
				aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));
					
				word_32bits =
						Inst_Aux.getOpcode()											// OP
						+ "" + Library.getCodeReg(aux.LinhaIntr[1])						// RS
						+ "" + Library.ZERO												// 5(0)
						+ ""+ Library.signalExt((aux1.linha-currentLine+1) + "", 16);			// OFFSET
			}
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}


	private static String mapInst_SHIFT(Instructions Inst_Aux, RefInstruc aux)
	{
		String word_32bits = "";
	
		for (int i = 1; i <= 2; i++) 
		{
			if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
			{
				GeneralAnalisy.writerLogError("Verifique os Registrador: " + aux.LinhaIntr[i] );
			}
		}
		if (!(Integer.parseInt(aux.LinhaIntr[3]) >= 0 && Integer.parseInt(aux.LinhaIntr[3]) <= 31))
		{
			GeneralAnalisy.writerLogError("Verifique a Constante: " + aux.LinhaIntr[3]);
		}
		if (!ReaderFile.statusERROR)
		{
			//SRA rd, rt, sa
			word_32bits = 
					Inst_Aux.getOpcode()							// OP
					+""+Library.ZERO								// 5(0)
					+""+ Library.getCodeReg(aux.LinhaIntr[2]) 		// RT
					+""+ Library.getCodeReg(aux.LinhaIntr[1]) 		// RD
					+""+ Library.signalExt(aux.LinhaIntr[3], 5) 	// SA
					+""+ Inst_Aux.getFunction();					// FUN
		}
		
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}


	private static String mapInst_L_S(Instructions Inst_Aux, RefInstruc aux)
	{
		String word_32bits = "";
		String[] tok = aux.LinhaIntr[2].split("[\\( - \\)]");
		if (!(Library.registradores.containsKey(tok[1])	&& Library.registradores.containsKey(aux.LinhaIntr[1]))) 
		{
			GeneralAnalisy.writerLogError("Verificar os registradores - linha: " + aux.linha);
		}
		if (!ReaderFile.statusERROR)
		{
			//LW rt, offset(base)
			//SW rt, offset(base)
			word_32bits = 
					Inst_Aux.getOpcode()						// OP
					+""+ Library.getCodeReg(tok[1])				// BASE
					+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RT
					+""+ Library.getBin16(tok[0]);				// OFFSET
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}


	private static String mapInst_IU_UI(Instructions Inst_Aux, RefInstruc aux)
	{
		
		String word_32bits = "";
		int op = Inst_Aux.getOperandos();
		if (op == 3) 
		{
			for (int i = 1; i <op; i++)
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError(
							"Verificar os registrador: " + aux.LinhaIntr[i]);
				}
			}
				
			if (!(Integer.parseInt(aux.LinhaIntr[3]) <= 65535 && Integer.parseInt(aux.LinhaIntr[3]) >= 0))
			{
				GeneralAnalisy.writerLogError(
						"Verifique a faixa da constante: " + aux.LinhaIntr[3]);
			}

			if (!ReaderFile.statusERROR)
			{
				//ADDIU rt, rs, immediate
				word_32bits = 
						Inst_Aux.getOpcode() 						// OP
						+""+ Library.getCodeReg(aux.LinhaIntr[2])	// RS
						+""+ Library.getCodeReg(aux.LinhaIntr[1])   // RT
						+""+ Library.getBin16(aux.LinhaIntr[3]);	// immediate
			}
		} 
		else if (op == 2)
		{
			if (Library.registradores.containsKey(aux.LinhaIntr[1]))
			{	
				GeneralAnalisy.writerLogError(
						"Verificar os registrador: " + aux.LinhaIntr[1]);
			}
			if (!(Integer.parseInt(aux.LinhaIntr[2]) < 65536 && Integer.parseInt(aux.LinhaIntr[2]) >= 0))
			{
				GeneralAnalisy.writerLogError("Verifique a faixa da constante: " + aux.LinhaIntr[2]);
			}
			if (!ReaderFile.statusERROR)
			{
				
				word_32bits = 
						Inst_Aux.getOpcode()						// OP
						+""+ Library.ZERO							// 5(0)
						+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RT
						+""+ Library.getBin16(aux.LinhaIntr[2]);	// IMMEDIATE
				
			}
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}
	private static String mapInst_J(Instructions Inst_Aux, RefInstruc aux)
	{
		String word_32bits="";
		aux.LinhaIntr[1] += ":";
		if (!Library.labellist.contains(aux.LinhaIntr[1]))
		{
			GeneralAnalisy
					.writerLogError("Verificar a Label: " + aux.LinhaIntr[1]);
		}
		if (!ReaderFile.statusERROR)
		{
			RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[1].toUpperCase().split("\t"), 1);
			aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));
			word_32bits = 
						Inst_Aux.getOpcode()
						+""+ Library.signalExt((aux1.linha) + "", 26);
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}
	
	private static String mapInst_I(Instructions Inst_Aux, RefInstruc aux)
	{	
		String word_32bits="";
		int op = Inst_Aux.getOperandos();
		
		if (op == 3)
		{
			for (int i = 1; i <= op - 1; i++) 
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError(
							"Verifique os Registrador: " + aux.LinhaIntr[i]);
				}
			}
			if (!(Integer.parseInt(aux.LinhaIntr[3]) <= 0 || Integer.parseInt(aux.LinhaIntr[3]) > 0)) 
			{
				GeneralAnalisy.writerLogError("Verifique a constante: " + aux.LinhaIntr[3]);
			}
			if (!ReaderFile.statusERROR)
			{
				//ADDI rt, rs, immediate
				word_32bits = Inst_Aux.getOpcode()					// OP 
						+""+ Library.getCodeReg(aux.LinhaIntr[2])	// RS
						+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RT
						+""+ Library.getBin16(aux.LinhaIntr[3]); 	// IMMEDIATE
			}
		} 
		else if (op == 2) 
		{
			for (int i = 1; i <= op - 1; i++)
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{	GeneralAnalisy.writerLogError(
							"Verifique os Registrador: " + aux.LinhaIntr[i]);
				}
			}
			if (Library.labellist.contains(aux.LinhaIntr[2]+":"))
			{	
				aux.LinhaIntr[2] += ":";
				RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[2].toUpperCase().split("[\\t - \\s]"), 1);
				aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));
				aux.LinhaIntr[2] = (aux1.linha)+"";
			}

			if (!(Integer.parseInt(aux.LinhaIntr[2]) <= 0 || Integer.parseInt(aux.LinhaIntr[2]) > 0))
			{
				GeneralAnalisy.writerLogError(
						"Verifique a constante: " + aux.LinhaIntr[2]);
			}
			if (!ReaderFile.statusERROR)
			{
				if(Inst_Aux.getName().equals("LUI"))
				{	
					
					word_32bits = 
							Inst_Aux.getOpcode()						// OP
							+""+ Library.ZERO							// 5(0)
							+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RT
							+""+ Library.getBin16(aux.LinhaIntr[2]);	// IMMEDIATE
					
				}
				else {
				word_32bits = Inst_Aux.getOpcode()					// OP
						+""+ Library.getCodeReg(aux.LinhaIntr[1])	// RS
						+""+ Library.ZERO							// 5(0)
						+""+ Library.getBin16(aux.LinhaIntr[2]); 	// OFFSET	
				}
			}
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}
	
	private static String mapInst_R(Instructions Inst_Aux, RefInstruc aux)
	{
		String word_32bits="";
		int op = Inst_Aux.getOperandos();
		if (op == 3) 
		{
			for (int i = 1; i <= op; i++)
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError(
							"Verifique os Registrador: " + aux.LinhaIntr[i] );
				}
			}
			if (!ReaderFile.statusERROR)
			{
				// ADD rd, rs, rt 
				// op rs rt rd sh fun
				word_32bits = 
						Inst_Aux.getOpcode()						// OP
						+""+ Library.getCodeReg(aux.LinhaIntr[2]) 	// RS
						+""+ Library.getCodeReg(aux.LinhaIntr[3]) 	// RT
						+""+ Library.getCodeReg(aux.LinhaIntr[1]) 	// RD
						+""+ Inst_Aux.getShitfAmount()				// SH
						+""+ Inst_Aux.getFunction();				// Fun
			}
		} 
		else if (op == 2) 
		{

			for (int i = 1; i <= op; i++)
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError(
							"Verifique os Registrador: " + aux.LinhaIntr[i] );
				}
			}
			if (!ReaderFile.statusERROR)
			{
				//CLZ rd, rs 
				//011100 rs rt rd 000000	100000
				
				word_32bits = 
						Inst_Aux.getOpcode()						// OP
						+""+  Library.getCodeReg(aux.LinhaIntr[1])	// RS
						+""+ Library.getCodeReg(aux.LinhaIntr[2])  							// RT
						+""+ Library.ZERO							// RD
						+""+ Inst_Aux.getShitfAmount() 				// SH
						+""+ Inst_Aux.getFunction();				// FUN
			}
		} 
		else if (op == 1) 
		{
		
			for (int i = 1; i <= op; i++) 
			{
				if (!Library.registradores.containsKey(aux.LinhaIntr[i]))
				{
					GeneralAnalisy.writerLogError(
							"Verifique os Registrador: " + aux.LinhaIntr[i] );
				}
			}
			if (!ReaderFile.statusERROR)
			{
				if(Inst_Aux.getName().equals("MFHI")||Inst_Aux.getName().equals("MFLO"))
				{
					word_32bits = 
							Inst_Aux.getOpcode()							// OP
							+""+Library.ZERO								// 5(0)
							+""+Library.ZERO								// 5(0)
							+""+Library.getCodeReg(aux.LinhaIntr[1])		// RD
							+""+Inst_Aux.getShitfAmount()					// 5(0)	
							+""+Inst_Aux.getFunction();						// FUN
								
				}
				else
				{
					word_32bits = 
							Inst_Aux.getOpcode()							// OP
							+""+Library.getCodeReg(aux.LinhaIntr[1])		// RS
							+""+Library.ZERO								// 5(0)
							+""+Library.ZERO								// 5(0)
							+""+Inst_Aux.getShitfAmount()					// 5(0)	
							+""+Inst_Aux.getFunction();	
				}
			
			
			}
		}
		Debuger.sysPrinfT(word_32bits);
		return word_32bits;
	}
	
	
	public static void mountBinary() throws IOException {
		String []fil = (ReaderFile.nameFile.split("\\."));
		String path = "s_"+fil[0]+".txt";
		BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path));
		String linha = "";
		if (ReaderFile.erros == 0) {
			buffWrite.append(Library.getBin32(ReaderFile.nInstr+""));
			for(String lin: memoria_flash)
			{
				System.out.println(lin);
				buffWrite.newLine();
				buffWrite.append(lin);
				
			}
			GeneralAnalisy.writerLogError("Ta saindo da Jaula o Monstro! Saiu de Casa e programou pra caralho !");
		} else {
			GeneralAnalisy.writerLogError("N�o vai d�! pra montar o bin�rio existem " + ReaderFile.erros
					+ " erro(s) no c�digo." + " Saiu de CASA e n�o programou pra caralho!");
		}
		buffWrite.close();
	}

}
