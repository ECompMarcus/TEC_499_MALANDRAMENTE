package br.uefs.control;

import br.uefs.lib.*;

public class GeneralAnalisy {

	public static int handlerTypeInstructions(String inst) {
		// System.out.println(inst);
		Instructions aux = new Instructions(inst, "1");
		for (int i = 0; i < Library.diretivas.length; i++)
			if (Library.diretivas[i].equals(inst))
				return 9;

		if (inst.matches("\\w+\\d*\\:$")) {
			return 9;
		} else if (Library.list_instructions.contains(aux)) {

			int index = Library.list_instructions.indexOf(aux);
			Instructions a = Library.list_instructions.get(index);

			if (a.getName().equals("LW") || a.getName().equals("LB") || a.getName().equals("LH")
					|| a.getName().equals("SW") || a.getName().equals("SB") || a.getName().equals("SH")) {
				return 5;
			} else if (inst.matches("^[A-Z]+UI?IU")) {
				return 4;
			} else if (a.getName().equals("SLL") || a.getName().equals("SRL") || a.getName().equals("SRA")
					|| a.getName().equals("ROTR")) {
				return 6;
			} else if (a.getName().equals("BEQ") || a.getName().equals("BNE") || a.getName().equals("BEQZ")
					|| a.getName().equals("BNEZ")) {
				return 7;
			}
			

			return a.getType();
		}
		return 10;
	}

	public boolean instructionsFormatExists(String linha) {

		String[] tokens = linha.trim().split("\t");
		Library.list_instructions.contains(tokens[0]);
		return false;
	}

	public static void writerLogError(String linha) {
		System.err.println(linha);
		ReaderFile.statusERROR = true;
		ReaderFile.erros++;
	}

	public static Instructions getInstruction(String inst) {
		Instructions aux = new Instructions(inst, "1");
		int index = Library.list_instructions.indexOf(aux);
		return Library.list_instructions.get(index);
	}

}
