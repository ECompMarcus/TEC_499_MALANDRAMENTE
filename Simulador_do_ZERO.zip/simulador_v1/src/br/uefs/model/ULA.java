package br.uefs.model;

public class ULA {
	 
	public static int OVERFLOW;
	public static int ZERO;
	 
	public static int ADD(int RA, int RB) {
		
		int RESUL = RA + RB;
		
		if(RESUL > Integer.MAX_VALUE)
			OVERFLOW = 1;
		else 
			OVERFLOW = 0;
		
		return RESUL;
	}

	public static int AND(int RA, int RB) {
		return RA & RB;
	}

	public static int OR(int RA, int RB) {
		return RA|RB;
	}

	public static int XOR(int RA, int RB) {
		return RA^RB;
	}

	public static int MUL(int RA, int RB) {
		
		return RA*RB;
	}
	public static int[] MULT(int RA, int RB)
	{
		int[] part_hielo = null;
		return part_hielo;
	}

	public static int NOR(int RA, int RB) {
		return ~(RA | RB);
	}
	public static int SRL(int RA, int RB) {
		return RA >> RB;
	}
	public static int SRA(int RA, int RB) {
		return RA >>> RB;
	}
	public static int MOVN(int RA) {
		return (RA != 0)? (ZERO = 1): (ZERO = 0);
	}

	public static int MOVZ(int RA, int RB) {
		return (RA == 0)? (ZERO = 1): (ZERO = 0);
	}

	public static int SLT(int RA, int RB) {
		return (RA < RB)? (ZERO = 1): (ZERO = 0);
	}
	public static int SLL(int RA, int RB) {
		return RA << RB;
	}

	public static int BEQ(int RA, int RB) {
		return (RA == RB)? (ZERO = 1): (ZERO = 0);
	}

	public static int BNE(int RA, int RB) {
		return (RA != RB)? (ZERO = 1): (ZERO = 0);
	}
	public static int BLTZ(int RA) {
		return (RA < 0)? (ZERO = 1): (ZERO = 0);
	}
	
	public static int BGTZ(int RA) {
		return (RA > 0)? (ZERO = 1): (ZERO = 0);
	}
	
	public static int SEB(int RA) {
		return AND(RA, 255);
	}
	
	public static int SEH(int RA) {
		return AND(RA, 65535);
	}
	
	public static int CLZ(int RA) { 
		int lz = 0;
		String dada = Integer.toString(RA);
		
		int i = dada.length();
		
		while ( i != 0) {
			if ( dada.charAt(i) == '0')
			lz++;
			
			i--;
		}
		return lz;
	}
	public static int CLO(int RA) { 
		int lz = 0;
		String dada = Integer.toString(RA);
		
		int i = dada.length();
		
		while ( i != 0) {
			if ( dada.charAt(i) == '1')
			lz++;
			
			i--;
		}
		return lz;
	}
	
	public static int DIV(int RA, int RB) {
		return RA / RB;
	}
}
