package br.uefs.model;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.text.html.HTMLEditorKit.Parser;

import br.uefs.debuger.Debuger;



public class MEMORY {

	public static Integer size = 10000;
	public static String [] internalMemory = new String[size];
	public static Integer instruNumber = 0;
	static int internalMemorySize=0;
	
	
	public static void mountMemory(String name) throws IOException
	{
		FileInputStream stream = null;
		stream = new FileInputStream(name);
		InputStreamReader reader = new InputStreamReader(stream);
		BufferedReader br = new BufferedReader(reader);
		String linha = br.readLine();
		boolean number = true;
		
		while(linha != null){
			
			if(number)
			{
				instruNumber = Integer.parseInt(linha,2);
				Debuger.sysPrinfT(instruNumber+"");
				number = false;
			}
			else
			{
				internalMemory[internalMemorySize++] = linha;
			}
			linha = br.readLine();
		}
		
		
	}
	public static String getBinMemory(int i)
	{
		return internalMemory[i];
	}
	
	public static int getSizeCurrent()
	{
		return internalMemorySize;
	}
}
