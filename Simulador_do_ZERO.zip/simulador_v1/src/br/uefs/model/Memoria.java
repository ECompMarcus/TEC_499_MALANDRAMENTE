package br.uefs.model;

public class Memoria {

	public int memoria_interna_size = 65535;
	public String [] memoria_compartilhada = new String[memoria_interna_size];

	public Memoria()
	{
		super();
	}
	
	public void escrever_memoria_32B(int endereco, String valor)
	{
		memoria_compartilhada[endereco] = valor;
	}
	public String ler_memoria_32B(int endereco)
	{
		return memoria_compartilhada[endereco];
	}
	public void escrever_memoria_16B(int endereco, String valor)
	{
		//0000 0000 0000 0000 0000 0000 0000 00
		memoria_compartilhada[endereco] = valor.substring(0,17) + memoria_compartilhada[endereco].substring(17, 32);
	}
	public String ler_memoria_16B(int endereco)
	{
		return memoria_compartilhada[endereco].substring(0, 17);
	}
	public void escrever_memoria_8B(int endereco, String valor)
	{
		memoria_compartilhada[endereco] = valor.substring(0,8) + memoria_compartilhada[endereco].substring(8, 31);
	}
	public String ler_memoria_8B(int endereco)
	{
		return memoria_compartilhada[endereco].substring(0, 8);
	}
}
