package br.uefs.model;

public class PC {
	int pc = 0;
}
