package br.uefs.model;

import br.uefs.debuger.Debuger;

public class UnidadeControle {

	public Registradores banco_registradores = new Registradores();
	public UlaOP operador_ula = new UlaOP();
	public Memoria memoria = new Memoria();
	
	int size_sinais = 9;
	int size_op_ula = 8;
	int []sinais = new int[size_sinais];
	int []UlaOP = new int[size_op_ula];
	
	public void decoder(String decoder) {
		Debuger.sysPrinfT(decoder);
	
		String token_0_5,token_6_10,token_11_15,token_16_20,token_21_25,token_26_31;
		int  int_token_0_5;
		
		token_0_5 = decoder.substring(0,6);		int_token_0_5 = Integer.parseUnsignedInt(token_0_5,2);
		token_6_10 = decoder.substring(6,11);	// int_token_6_10 = Integer.parseInt(token_6_10,2);
		token_11_15 = decoder.substring(11,16);	// int_token_11_15 = Integer.parseInt(token_11_15,2);
		token_16_20 = decoder.substring(16,21);	// int_token_16_20 = Integer.parseInt(token_16_20,2);
		token_21_25 = decoder.substring(21,26);	// int_token_21_25 = Integer.parseInt(token_21_25,2);
		token_26_31 = decoder.substring(26,32);	// int_token_26_31 = Integer.parseInt(token_26_31,2);	
		
		int funcao=Integer.parseUnsignedInt(token_26_31,2),
				RA = Integer.parseUnsignedInt(token_6_10,2),
				RB=Integer.parseUnsignedInt(token_11_15,2),
				RD=Integer.parseUnsignedInt(token_16_20,2),
				SFA = Integer.parseUnsignedInt(token_21_25,2);
		
		// tipo R
		if(int_token_0_5 ==0b000000)
		{
			
			// PARA MULTIPLICA��O E DIVIS�O QUE USA O HI e o LO ~~
			//  DIV - DIVU - MULT - MULTU
			if((funcao == 0b011010 || funcao == 0b011011 || funcao == 0b011000 || funcao == 0b011001))
			{
				int[] resultado = operador_ula.operacao_accumulador(int_token_0_5,funcao, banco_registradores.getValor(RA),banco_registradores.getValor(RB) );
				banco_registradores.setHi(resultado[0]);
				banco_registradores.setLo(resultado[1]);				
			}
			//MFHI ~~
			else if(funcao == 0b010000)
			{
				banco_registradores.setValor(RD,banco_registradores.getHi());
			} 
			//MFLO~~
			else if (funcao == 0b010010)
			{
				banco_registradores.setValor(RD,banco_registradores.getLo());
			} 
			//MTHI~~
			else if (funcao == 0b010001)
			{
				banco_registradores.setHi(banco_registradores.getValor(RD));
			}
			//MTLO~~
			else if (funcao == 0b010011)
			{
				banco_registradores.setLo(banco_registradores.getValor(RD));
			}
			// SLLV~~- SRAV~~ - SRLV~~
			else if((funcao == 0b000100 || funcao == 0b000111 || funcao == 0b000110))
			{
				int resultado = operador_ula.operation_R(int_token_0_5, funcao, banco_registradores.getValor(RB),banco_registradores.getValor(RA));
				banco_registradores.setValor(RD, resultado);
			}
			//SLL~~ - SRA~~ -  SRL~~
			else if((funcao == 0b000000 || funcao == 0b000011 || funcao == 0b000010))
			{
				int resultado = operador_ula.operation_R(int_token_0_5, funcao, banco_registradores.getValor(RB),SFA);
				banco_registradores.setValor(RD, resultado);
			}
			// JR~~
			else if(funcao == 0b001001 && RD == 0b00000)
			{
				banco_registradores.setPc(banco_registradores.getValor(RA));
			}
			// JALR~~
			else if(funcao == 0b001001 && RD != 0b00000)
			{
				banco_registradores.setValor(31, banco_registradores.getPc() + 1);
				banco_registradores.setPc(banco_registradores.getValor(RA));
			}
			//MOVE ~~
			else if (funcao == 0b001100)
			{
				int Resultado = operador_ula.operation_R(int_token_0_5, funcao, banco_registradores.getValor(RA),  banco_registradores.getValor(RB));
				banco_registradores.setValor( RD, Resultado);
			}
			// RESTANTE DAS INSTRU��ES R
			else 
			{
				int Resultado = operador_ula.operation_R(int_token_0_5, funcao, banco_registradores.getValor(RA),  banco_registradores.getValor(RB));
				if(ULA.ZERO == 0)
					banco_registradores.setValor( RD, Resultado);
				
				if(ULA.OVERFLOW == 1)
					Debuger.sysPrinfT("Overflow, na instru��o:" + token_0_5 +" "+token_26_31);	
			}
		}
		// LI
		else if(int_token_0_5 == 0b100101)
		{
			// TODO FAZER LI
		}
			// JAL ~~
		else if (int_token_0_5 == 0b000011)
		{
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);
			banco_registradores.setValor(31, banco_registradores.getPc() + 1);
			banco_registradores.setPc(OPERANDO_CONST + 1);
		}
		// J ~~
		else if(int_token_0_5 == 0b000010)
		{
			int ENDERECO = Integer.parseUnsignedInt(decoder.substring(6,32),2);
			Debuger.sysPrinfT(ENDERECO+"");
			banco_registradores.setPc(ENDERECO+1);			
		}
		// BGTZ ~~
		else if(int_token_0_5 == 0b000111 && (RB == 0b00000) )
		{
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);
			operador_ula.BGTZ_BLTZ(int_token_0_5, banco_registradores.getValor(RB));
			if(ULA.ZERO == 1)
				banco_registradores.setPc( banco_registradores.getPc() +OPERANDO_CONST +1);
				
		}
		// BLTZ ~~
		else if(int_token_0_5 == 0b000001 && (RB == 0b00000) )
		{
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);
			operador_ula.BGTZ_BLTZ(int_token_0_5, banco_registradores.getValor(RB));
			if(ULA.ZERO == 1)
				banco_registradores.setPc( banco_registradores.getPc() +OPERANDO_CONST +1);
			
		}
		else if(int_token_0_5 == 0b011111)
		{			// EXT	~~			INS ~~
			if((funcao == 0b000000 || funcao == 0b000100))
			{
				// TODO FAZER EXT e INS
			}
			else if(funcao == 0b100000)
			{
				//SEB ~~
				if(SFA == 0b10000)
				{
					// TODO FAZER SEB
				}
				//SEH~~
				else if(SFA == 0b11000)
				{
					// TODO FAZER SEH
				}
				// WSBH~~			
				else if(SFA == 0b00010)
				{
					// TODO FAZER WSBH
				}
			}
		}
			// FUNCOES ESPECIAIS ~~
		else if(int_token_0_5 == 0b011100)
		{ 
			// MUL ~~
			if(funcao == 0b000010)
			{	
				int resultado = operador_ula.operation_R(int_token_0_5,funcao, banco_registradores.getValor(RA),banco_registradores.getValor(RB));
				
				if(ULA.ZERO == 0)
					banco_registradores.setValor(RD, resultado);
				if(ULA.OVERFLOW == 1)
					Debuger.sysPrinfT("Overflow na intru��o "+int_token_0_5 +" "+ funcao);
					
					
			}
					// MADD		~~			MADDU~~
			else if(	(funcao == 0b000000 || funcao == 0b000001) )
			{
				int[] resultado = operador_ula.operacao_accumulador(int_token_0_5,funcao, banco_registradores.getValor(RA),banco_registradores.getValor(RB) );
				banco_registradores.setHi( banco_registradores.getHi() + resultado[0]);
				banco_registradores.setLo( banco_registradores.getLo() + resultado[1]);	
			}
			//					MSUB   ~~    MSUBU~~
			else if((funcao == 0b000100 || funcao == 0b000101))
			{
				int[] resultado = operador_ula.operacao_accumulador(int_token_0_5,funcao, banco_registradores.getValor(RA),banco_registradores.getValor(RB) );
				banco_registradores.setHi( banco_registradores.getHi() - resultado[0]);
				banco_registradores.setLo( banco_registradores.getLo() - resultado[1]);
			}
								// CLZ	~~			CLO~~
			else if((funcao == 0b100000 || funcao == 0b100001))
			{
				// TODO CLZ~~ e CLO ~~
			}
		}
		// LUI ~~
		else if (int_token_0_5 == 0b001111)
		{
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);
			int resultado = operador_ula.operation_R(000000, 000000, OPERANDO_CONST, 16);
			banco_registradores.setValor(RB, resultado);
		}
						// XORI		~~			SLTI~~
		else if (	int_token_0_5 == 0b001110 ||int_token_0_5 == 0b001010
							//SLTIU	 ~~					ADDIU ~~
					|| int_token_0_5 == 0b001011 || int_token_0_5 == 0b001001
							// ANDI ~~					ORI ~~
					||int_token_0_5 == 0b001100 || int_token_0_5 == 0b001101   )
		{
				RA = Integer.parseInt(token_6_10,2);
				RB = Integer.parseInt(token_11_15,2);
				
				int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);	
			
				int resultado = operador_ula.operation_I(int_token_0_5,  RA, OPERANDO_CONST);
				banco_registradores.setValor(RB, resultado);
		}
		// BEQ ~~ e BNE~~
		else if (int_token_0_5 == 0b000100 || int_token_0_5 == 0b000101)
		{
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);	
			if(OPERANDO_CONST >= 32766) {
				OPERANDO_CONST = complementoA2(OPERANDO_CONST);
			}
			operador_ula.operation_I(int_token_0_5, banco_registradores.getValor(RA),banco_registradores.getValor(RB));
			// endere�amento relativo 
			if(ULA.ZERO == 1) 
				banco_registradores.setPc(banco_registradores.getPc()+OPERANDO_CONST + 1 ); 
		
		}
		else if(int_token_0_5 == 0b001000) {
			
			int OPERANDO_CONST= Integer.parseUnsignedInt(decoder.substring(16,32),2);
			if(OPERANDO_CONST > 32767) {
				OPERANDO_CONST = this.complementoA2(OPERANDO_CONST);
			}
			Debuger.sysPrinfT(""+RB);
			int resultado = operador_ula.operation_I(int_token_0_5, banco_registradores.getValor(RA), OPERANDO_CONST);
			if(ULA.ZERO == 0 )
				banco_registradores.setValor(RB, resultado);
			
			if(ULA.OVERFLOW == 1)
				Debuger.sysPrinfT("OVERFLOW ADDI");
		}
			
		
		
		
		
		
	}
	
	private int  complementoA2(int constante) { 
		int resultado;
		
		resultado = ~constante; 
		resultado++;
		
		String sub = Integer.toBinaryString(resultado);
		sub = sub.substring(16);
		
		resultado = Integer.parseInt(sub, 2);
		resultado = ~resultado;
		resultado++;
		return resultado;
	}
	
	
}
