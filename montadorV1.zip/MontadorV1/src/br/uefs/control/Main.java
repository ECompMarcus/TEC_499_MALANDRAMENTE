package br.uefs.control;


import java.io.IOException;

import br.uefs.debuger.Debuger;
import br.uefs.lib.Instructions;
import br.uefs.lib.Library;

public class Main {

	public static void main(String[] args) {

		try {
		Debuger.enable=false;
		Library.readerInstructions();
		Library.readerRegisters();
		ReaderFile.readerFile("teste.txt");
		//ReaderFile.readerFile("shift.asm");
		//ReaderFile.readerFile("acc.asm");
		//ReaderFile.readerFile("arith.asm");
		//ReaderFile.readerFile("branch.asm");
		//ReaderFile.readerFile("cond.asm");
		////ReaderFile.readerFile("logic.asm");
		//ReaderFile.readerFile("mul.asm");
		//ReaderFile.readerFile("ls.asm");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int i = 1;
		MapingMemory.map();
	//		for(String x: MapingMemory.memoria_flash)
	//		{
	//			System.err.println(i+++"\t"+x);
	//		}
			
		
				
	//		for(Instructions x : Library.list_instructions)
	//		{
	//			System.err.println(x.getOpcode()+"\t"+x.getName()+"\t"+x.getType()+"\t"+x.getFunction()+"\t"+x.getOperandos()+"\t"+x.getShitfAmount());
	//		}
		
		
	//	MapingMemory.mountBinary();
		//System.out.println(ReaderFile.instrucoes_lidas.size() +" "+ MapingMemory.memoria_flash.size());
	//	int i = 0;
	//	for(String bin : MapingMemory.memoria_flash)
	//	{
	//			System.err.println((i++)+" "+bin);
	//	}
		
	}

}
